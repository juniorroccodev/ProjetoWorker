package calcular.somarestapiwevo.controller;

import calcular.somarestapiwevo.models.Calculadora;
import calcular.somarestapiwevo.service.CalculadoraService;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RequiredArgsConstructor(onConstructor = @__(@Autowired))
@RestController
@RequestMapping("/soma")
public class CalculadoraController {

    private final CalculadoraService calculadoraService;

    @PostMapping
    public ResponseEntity<Calculadora> salvar(@RequestBody Calculadora calculadora){
        return ResponseEntity.ok(calculadoraService.salvar(calculadora));
    }
}
