package calcular.somarestapiwevo.models;

import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import lombok.*;

import javax.persistence.*;
import java.io.Serializable;
import java.math.BigDecimal;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
@Builder
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
@Entity
@SequenceGenerator(name = "seq_calculadora", sequenceName = "seq_calculadora", allocationSize = 1, initialValue = 1)
@ToString
public class Calculadora implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    private Long id;
    private BigDecimal numero1;
    private BigDecimal numero2;
    private String resposta;
}
