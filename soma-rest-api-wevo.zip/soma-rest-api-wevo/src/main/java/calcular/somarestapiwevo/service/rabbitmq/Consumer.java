package calcular.somarestapiwevo.service.rabbitmq;

import calcular.somarestapiwevo.models.Calculadora;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.messaging.handler.annotation.Payload;

public class Consumer {

    @RabbitListener(queues = {"${queue.name}"})
    public void consumer (@Payload Calculadora calculadora){
        System.out.println("Mensagem recebida: " + calculadora);

    }
}
