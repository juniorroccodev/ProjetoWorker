package calcular.somarestapiwevo.service;

import calcular.somarestapiwevo.models.Calculadora;
import calcular.somarestapiwevo.repository.CalculadoraRepository;
import calcular.somarestapiwevo.service.rabbitmq.Producer;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@RequiredArgsConstructor(onConstructor = @__(@Autowired))
@Service
public class CalculadoraService {

    private final CalculadoraRepository calculadoraRepository;
    private final Producer producer;

    public Calculadora salvar(Calculadora calculadora) {
        calculadora = calculadoraRepository.save(calculadora);
        producer.enviarCalculo(calculadora);
        return calculadora;
    }

}
