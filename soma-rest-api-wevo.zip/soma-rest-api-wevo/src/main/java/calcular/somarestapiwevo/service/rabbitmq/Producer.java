package calcular.somarestapiwevo.service.rabbitmq;

import calcular.somarestapiwevo.models.Calculadora;
import org.springframework.amqp.core.Queue;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

@Service
public class Producer {

    @Autowired
    private RabbitTemplate rabbitTemplate;
    @Autowired
    private Queue queue;


    @PostMapping
    public void enviarCalculo(Calculadora calculadora ){
        rabbitTemplate.convertAndSend(queue.getName(), calculadora);
    }

}
