package calcular.somarestapiwevo.repository;

import calcular.somarestapiwevo.models.Calculadora;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CalculadoraRepository extends JpaRepository<Calculadora, Long> {

}
